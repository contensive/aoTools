
using Contensive.BaseClasses;

namespace Contensive.Addons.Tools {
    public class AddonClass : AddonBaseClass {
        public override object Execute(CPBaseClass cp) {
            return "Hello World";
        }
    }
}
