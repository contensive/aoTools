﻿
namespace Contensive.Addons.Tools {
    namespace Models.Db {
        public class PageContentModel : Contensive.Models.Db.PageContentModel {
        }
    }
}
