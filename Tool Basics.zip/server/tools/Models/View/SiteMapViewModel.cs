using Contensive.Addons.Tools.Models.Db;
using Contensive.BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Models.View {
    /// <summary>
    /// View model for the Site Map display
    /// </summary>
    public class SiteMapViewModel {
        public bool hasPages { get; set; }
        public List<SiteMapPageViewModel> pages { get; set; }

        /// <summary>
        /// Create the site map view model from the database
        /// </summary>
        public static SiteMapViewModel create(CPBaseClass cp) {
            try {
                var result = new SiteMapViewModel {
                    pages = new List<SiteMapPageViewModel>()
                };

                // Load all active pages
                var allPages = PageContentModel.createList<PageContentModel>(cp, "(active<>0)", "name");
                if (allPages == null || !allPages.Any()) {
                    result.hasPages = false;
                    return result;
                }

                result.hasPages = true;

                // Organize pages by parent
                var pagesByParent = new Dictionary<int, List<PageContentModel>>();
                foreach (var page in allPages) {
                    int parentId = page.parentId;
                    if (!pagesByParent.ContainsKey(parentId)) {
                        pagesByParent[parentId] = new List<PageContentModel>();
                    }
                    pagesByParent[parentId].Add(page);
                }

                // Build the tree starting from root pages (parentId = 0)
                result.pages = buildPageTree(cp, pagesByParent, 0, 0);

                return result;
            } catch (Exception ex) {
                cp.Site.ErrorReport(ex);
                return new SiteMapViewModel { hasPages = false };
            }
        }

        /// <summary>
        /// Recursively build the page tree
        /// </summary>
        private static List<SiteMapPageViewModel> buildPageTree(CPBaseClass cp, Dictionary<int, List<PageContentModel>> pagesByParent, int parentId, int depth) {
            var result = new List<SiteMapPageViewModel>();

            if (!pagesByParent.ContainsKey(parentId)) {
                return result;
            }

            foreach (var page in pagesByParent[parentId]) {
                var pageViewModel = new SiteMapPageViewModel {
                    id = page.id,
                    name = cp.Utils.EncodeText(page.name),
                    depth = depth,
                    paddingLeft = depth * 20,
                    isRoot = depth == 0,
                    children = new List<SiteMapPageViewModel>()
                };

                // Check if this page has children
                if (pagesByParent.ContainsKey(page.id)) {
                    pageViewModel.hasChildren = true;
                    pageViewModel.children = buildPageTree(cp, pagesByParent, page.id, depth + 1);
                } else {
                    pageViewModel.hasChildren = false;
                }

                // Build the HTML for this page node
                pageViewModel.pageHtml = buildPageHtml(pageViewModel);

                result.Add(pageViewModel);
            }

            return result;
        }

        /// <summary>
        /// Build HTML for a single page node
        /// </summary>
        private static string buildPageHtml(SiteMapPageViewModel page) {
            var html = new StringBuilder();
            string indent = new string(' ', page.depth * 4);

            html.Append($"{indent}<li class=\"sitemap-page\" style=\"padding-left: {page.paddingLeft}px;\">");
            html.Append($"<span class=\"sitemap-page-name{(page.isRoot ? " root" : "")}\">{page.name}</span>");
            html.Append($" <span class=\"sitemap-page-id\">(ID: {page.id})</span>");

            if (page.hasChildren) {
                html.Append($"{indent}<ul class=\"sitemap-children\">");
                foreach (var child in page.children) {
                    html.Append(child.pageHtml);
                }
                html.Append($"{indent}</ul>");
            }

            html.Append($"{indent}</li>");

            return html.ToString();
        }
    }

    /// <summary>
    /// View model for individual page in the site map
    /// </summary>
    public class SiteMapPageViewModel {
        public int id { get; set; }
        public string name { get; set; }
        public int depth { get; set; }
        public int paddingLeft { get; set; }
        public bool isRoot { get; set; }
        public bool hasChildren { get; set; }
        public List<SiteMapPageViewModel> children { get; set; }
        public string pageHtml { get; set; }
    }
}
